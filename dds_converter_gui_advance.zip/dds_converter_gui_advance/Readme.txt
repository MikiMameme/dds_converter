========================================
DDS to PNG Converter GUI
（DDS画像変換ツール）
========================================

■ 概要
このツールは、ゲームなどで使われる「.dds」形式の画像を、
ワンクリックで「.png」形式に変換できるWindows用アプリです。

Skyrim AE（フォトモードMODなど）で撮影したスクリーンショットを
手軽に閲覧・編集できるようにする目的で作成しました。

フォルダ単位・ファイル単位の変換に対応し、
進行状況もバーで表示されるシンプルな設計です。

----------------------------------------
■ 使い方
----------------------------------------

1. 「DDS to PNG Converter.exe」を実行します。

2. 起動後、メニューから「ファイルを選択」または「フォルダを選択」をクリックします。
   - ファイル単体を選ぶと、その1枚を変換します。
   - フォルダを選ぶと、中のすべてのDDSファイルをPNGに変換します。

3. 「保存先を選択」で出力先フォルダを指定します。

4. 「変換開始」ボタンを押すと処理が始まります。
   - フォルダ変換時は進行バーで進捗が表示されます。

5. 変換完了後、指定フォルダ内に「.png」ファイルが出力されます。


----------------------------------------
■ 動作環境
----------------------------------------

・対応OS：Windows 10 / 11（64bit）
・Python：不要（EXE版に同梱済み）
・必要ライブラリ：
　 すべてアプリに同梱済み（Pillowなど）

そのまま「DDS to PNG Converter.exe」を実行するだけで動作します。


----------------------------------------
■ 既知の制限事項
----------------------------------------

・入力は「.dds」形式のみ対応しています。
・透過情報（アルファチャンネル）は保持されますが、
　ゲームによっては色味が若干異なる場合があります。
・出力形式は「.png」のみです。


----------------------------------------
■ ライセンス
----------------------------------------

本ソフトウェアは MIT ライセンスで公開されています。

MIT License

Copyright (c) 2025 K.N(Miki Mame) & ChatGPT (OpenAI)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
OR OTHER DEALINGS IN THE SOFTWARE.


----------------------------------------
■ 免責事項
----------------------------------------

・このツールの使用によって発生したいかなる損害も、作者は一切責任を負いません。
・MODデータやゲームデータの変換・再配布については、
　各ゲームおよびMODの利用規約に従ってください。
・変換結果を商用利用する場合は、必ず利用元のライセンスをご確認ください。


----------------------------------------
■ 開発協力
----------------------------------------

・プログラム設計・UI実装：K.N(Miki Mame)
・AI支援（コード生成・構成提案）：ChatGPT（OpenAI）

このソフトは、学習目的・実用目的の両方で開発されました。


----------------------------------------
■ 更新履歴
----------------------------------------
ver 1.0.0（2025/10）
 - 初版リリース（フォルダ/ファイル単体変換対応）
 - 進行状況バー実装
 - Python不要のEXE版配布開始

----------------------------------------
■ 配布・転載について
----------------------------------------
・本ツールはMITライセンスのもと自由に再配布可能です。
・再配布時は、README.txtおよびLICENSEファイルを同梱してください。
・改変・改良版を公開する場合は、作者クレジットを残してください。

----------------------------------------
■ お問い合わせ
----------------------------------------
GitHubリポジトリ（ソース公開先）：
https://github.com/MikiMameme/dds_converter
X（旧Twitter）：
https://x.com/Miki_Mameme
Youtube：
https://www.youtube.com/@Miki_Mameme